const API_ORIGIN = ''; // Set to your backend URL for separate frontend/backend hosting.
const $ = id => document.getElementById(id);
const state = { servers: [], selected: null, running: false, abort: null, samples: [], history: JSON.parse(localStorage.getItem('nexus-history') || '[]') };
const fmt = n => Number.isFinite(n) ? (n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2)) : '—';
const base = () => state.selected?.baseUrl || API_ORIGIN;
function setStatus(s){$('testState').textContent=s.toUpperCase();$('connectionLabel').textContent=s.toUpperCase();}
function setPhase(s){$('phaseLabel').textContent=s;}
function drawChart(){
 const c=$('speedChart'), dpr=window.devicePixelRatio||1, w=c.clientWidth, h=c.clientHeight;
 c.width=w*dpr;c.height=h*dpr;const x=c.getContext('2d');x.scale(dpr,dpr);x.clearRect(0,0,w,h);
 for(let i=1;i<4;i++){x.strokeStyle='#edf0f5';x.lineWidth=1;x.beginPath();x.moveTo(0,h*i/4);x.lineTo(w,h*i/4);x.stroke();}
 const vals=state.samples.slice(-60);if(vals.length<2)return;
 const max=Math.max(10,...vals.map(v=>v.value))*1.15;
 for(const [key,color] of [['download','#17b8d2'],['upload','#8b6cf6']]){
  const arr=vals.filter(v=>v.kind===key);if(arr.length<2)continue;
  x.strokeStyle=color;x.lineWidth=2;x.beginPath();arr.forEach((v,i)=>{const px=(i/(Math.max(1,arr.length-1)))*w,py=h-(v.value/max)*(h-8)-4;i?x.lineTo(px,py):x.moveTo(px,py)});x.stroke();
 }
}
async function loadServers(){
 $('serverSelect').innerHTML='<option>Loading…</option>';
 try{
  const r=await fetch(API_ORIGIN+'/api/servers',{cache:'no-store'});if(!r.ok)throw Error('API '+r.status);
  const data=await r.json();state.servers=data.servers||[];
  $('serverSelect').innerHTML='';
  state.servers.forEach((s,i)=>{const o=document.createElement('option');o.value=s.id;o.textContent=`${s.name} — ${s.location}`;$('serverSelect').append(o);if(i===0)state.selected=s;});
  if(state.selected)$('serverSelect').value=state.selected.id;
  updateServerMeta();if($('autoServer').checked)await selectFastestServer();
 }catch(e){$('serverSelect').innerHTML='<option>Backend belum terhubung</option>';$('serverLocation').textContent='Deploy backend untuk mengaktifkan pengujian';$('testNote').textContent='Backend API tidak dapat dijangkau. Jalankan backend lokal atau deploy ke hosting.';}
}
function updateServerMeta(){$('serverLocation').textContent=state.selected?state.selected.location:'No server selected';}
async function selectFastestServer(){
 if(!state.servers.length)return;
 let best=null,bestMs=Infinity;
 for(const server of state.servers){
  const origin=server.baseUrl||API_ORIGIN;const samples=[];
  for(let i=0;i<3;i++){const t=performance.now();try{const r=await fetch(origin+'/api/health?probe='+Math.random(),{cache:'no-store'});if(r.ok)samples.push(performance.now()-t);}catch(e){}}
  if(samples.length){const avg=samples.reduce((a,b)=>a+b,0)/samples.length;if(avg<bestMs){bestMs=avg;best=server;}}
 }
 if(best){state.selected=best;$('serverSelect').value=best.id;updateServerMeta();$('serverLocation').textContent=best.location+' · '+fmt(bestMs)+' ms probe';}
}

$('serverSelect').addEventListener('change',()=>{state.selected=state.servers.find(s=>s.id===$('serverSelect').value)||null;updateServerMeta();});
$('autoServer').addEventListener('change',async()=>{$('serverSelect').disabled=$('autoServer').checked;if($('autoServer').checked)await selectFastestServer();});
$('refreshServers').onclick=loadServers;
$('clearHistory').onclick=()=>{state.history=[];localStorage.removeItem('nexus-history');renderHistory();};
function renderHistory(){
 const el=$('historyList');if(!state.history.length){el.innerHTML='<div class="empty-history">Your completed tests will appear here.</div>';return;}
 el.innerHTML=state.history.slice(0,8).map(h=>`<div class="history-item"><div><span>${new Date(h.date).toLocaleString()}</span><b>${h.server}</b></div><div><span>DOWNLOAD</span><b>${fmt(h.down)} Mbps</b></div><div><span>UPLOAD</span><b>${fmt(h.up)} Mbps</b></div><div><span>PING</span><b>${fmt(h.ping)} ms</b></div></div>`).join('');
}
function saveHistory(result){state.history.unshift({date:Date.now(),server:state.selected?.name||'Unknown',...result});state.history=state.history.slice(0,30);localStorage.setItem('nexus-history',JSON.stringify(state.history));renderHistory();}
async function measurePing(){
 setPhase('Measuring latency');const vals=[];
 for(let i=0;i<12;i++){const t=performance.now();try{const r=await fetch(base()+'/api/health?nocache='+Math.random(),{cache:'no-store',signal:state.abort.signal});if(!r.ok)throw Error();vals.push(performance.now()-t);}catch(e){if(state.abort.signal.aborted)throw e;}}
 if(!vals.length)throw Error('Server tidak merespons');
 const avg=vals.reduce((a,b)=>a+b,0)/vals.length;const jitter=vals.slice(1).reduce((a,b,i)=>a+Math.abs(b-vals[i]),0)/Math.max(1,vals.length-1);
 $('pingValue').innerHTML=`${fmt(avg)} <small>ms</small>`;$('jitterValue').innerHTML=`${fmt(jitter)} <small>ms</small>`;
 return {avg,jitter};
}
async function throughput(kind){
 setPhase(kind==='download'?'Measuring download':'Measuring upload');
 const duration=7000, start=performance.now();let bytes=0, latest=0, active=true;
 const controller=state.abort;
 if(kind==='download'){
  const workers=4;
  await Promise.all(Array.from({length:workers},async()=>{
   while(active&&!controller.signal.aborted&&performance.now()-start<duration){
    try{const r=await fetch(base()+'/api/download?size=12000000&x='+Math.random(),{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error('Download endpoint error');
     const reader=r.body.getReader();while(active){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;const now=performance.now();if(now-latest>250){const mbps=bytes*8/(Math.max(1,now-start))/1000;state.samples.push({kind,value:mbps});$('speedValue').textContent=fmt(mbps);latest=now;drawChart();}if(now-start>=duration){active=false;break;}}
    }catch(e){if(controller.signal.aborted)throw e;active=false;throw e;}
   }
  }));
 }else{
  const workers=3;
  await Promise.all(Array.from({length:workers},async()=>{
   while(active&&!controller.signal.aborted&&performance.now()-start<duration){
    const payload=new Uint8Array(1024*1024);crypto.getRandomValues(payload.subarray(0,65536)); // fill remainder with nontrivial bytes
    for(let i=65536;i<payload.length;i+=65536)payload.set(payload.subarray(0,65536),i);
    try{const r=await fetch(base()+'/api/upload?x='+Math.random(),{method:'POST',body:payload,cache:'no-store',signal:controller.signal});if(!r.ok)throw Error('Upload endpoint error');bytes+=payload.byteLength;
     const now=performance.now();if(now-latest>250){const mbps=bytes*8/(Math.max(1,now-start))/1000;state.samples.push({kind,value:mbps});$('speedValue').textContent=fmt(mbps);latest=now;drawChart();}
    }catch(e){if(controller.signal.aborted)throw e;active=false;throw e;}
   }
  }));
 }
 const elapsed=(performance.now()-start)/1000;return bytes*8/elapsed/1e6;
}
async function runTest(){
 if(state.running)return;
 if($('autoServer').checked)await selectFastestServer();
 if(!state.selected)return;
 state.running=true;state.abort=new AbortController();state.samples=[];drawChart();
 $('startBtn').disabled=true;$('stopBtn').disabled=false;$('downloadValue').innerHTML='— <small>Mbps</small>';$('uploadValue').innerHTML='— <small>Mbps</small>';$('loadedLatency').textContent='Measuring';$('packetLoss').textContent='Browser estimate';setStatus('Testing');
 try{
  const ping=await measurePing();
  const down=await throughput('download');$('downloadValue').innerHTML=`${fmt(down)} <small>Mbps</small>`;
  const up=await throughput('upload');$('uploadValue').innerHTML=`${fmt(up)} <small>Mbps</small>`;
  $('speedValue').textContent=fmt(down);$('meterLabel').textContent='DOWNLOAD PEAK';$('loadedLatency').textContent='Not separately measured';
  $('packetLoss').textContent='Not available in browser';
  saveHistory({down,up,ping:ping.avg});setPhase('Test completed');setStatus('Complete');
 }catch(e){if(e.name==='AbortError'){setPhase('Test stopped');setStatus('Stopped');}else{setPhase(e.message||'Test failed');setStatus('Error');console.error(e);}}
 finally{state.running=false;$('startBtn').disabled=false;$('stopBtn').disabled=true;}
}
$('startBtn').onclick=runTest;
$('stopBtn').onclick=()=>state.abort?.abort();
$('connectionType').textContent=navigator.connection?.effectiveType||'Not exposed by browser';
if(navigator.connection?.effectiveType)navigator.connection.addEventListener('change',()=>$('connectionType').textContent=navigator.connection.effectiveType);
async function getIp(){try{const r=await fetch('https://api.ipify.org?format=json');const d=await r.json();$('publicIp').textContent=d.ip;}catch{$('publicIp').textContent='Unavailable';}}
let installPrompt;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('installBtn').hidden=false;});
$('installBtn').onclick=async()=>{if(installPrompt){installPrompt.prompt();installPrompt=null;$('installBtn').hidden=true;}};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.warn));
window.addEventListener('resize',drawChart);renderHistory();drawChart();loadServers();getIp();
