# NEXUS SPEEDTEST — starter project

NEXUS is a Progressive Web App frontend plus a FastAPI measurement backend.

## Important measurement notes
- No browser speed test can guarantee 100% accuracy. Results vary with device, Wi-Fi/mobile signal, routing, server load and browser limits.
- Download/upload measure actual transferred bytes over elapsed wall-clock time.
- Browser ping here is HTTP round-trip time to `/api/health`, not ICMP ping.
- Jitter is calculated from consecutive HTTP RTT differences.
- Packet loss is not reported as an exact value: browsers cannot perform raw ICMP probes. Do not interpret an unavailable value as 0%.
- For credible multi-location tests, deploy a backend instance in each location and register its URL in `NEXUS_SERVERS_JSON`.

## Run locally

Requirements: Python 3.10+.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Serve the frontend on the same origin as the API. Easiest development option: copy `frontend/` contents into `backend/static` and add a static mount, or use a local reverse proxy. For quick testing, set `const API_ORIGIN = 'http://localhost:8000';` near the top of `frontend/app.js`, then serve `frontend/` with:

```bash
cd frontend
python -m http.server 5500
```

Also enable CORS on the backend:
`CORS_ORIGINS=http://localhost:5500 uvicorn main:app --host 0.0.0.0 --port 8000`

The frontend will then call the backend at that origin. Keep the CORS setting aligned with your frontend origin.

## Deploy backend
Deploy `backend/` as a Docker web service. The included Dockerfile starts Uvicorn and respects the hosting provider's `PORT`.

Environment variables:
- `NEXUS_SERVER_ID` (default `local`)
- `NEXUS_SERVER_NAME` (default `NEXUS Local Test Server`)
- `NEXUS_SERVER_LOCATION` (default `Configure location`)
- `CORS_ORIGINS` (comma-separated allowed frontend origins; use `*` only for public prototype)
- `MAX_UPLOAD_BYTES` (default 64 MiB)
- `NEXUS_SERVERS_JSON` (optional JSON array of additional deployed backends)

Example additional server configuration:
```json
[
  {"id":"sg-1","name":"NEXUS Singapore","location":"Singapore","baseUrl":"https://sg-api.example.com","enabled":true},
  {"id":"id-jkt-1","name":"NEXUS Jakarta","location":"Jakarta, Indonesia","baseUrl":"https://jkt-api.example.com","enabled":true}
]
```
Each URL must be a live NEXUS backend with valid TLS/HTTPS and CORS configured to allow the frontend origin. Do not add a location until an actual test node is deployed there.

## Deploy frontend
Host `frontend/` as a static site over HTTPS (GitHub Pages, Cloudflare Pages, Netlify, etc.). For production, set `API_ORIGIN` near the top of `app.js` to your backend HTTPS origin and ensure CORS is restricted to the exact frontend domain. Service worker/PWA install requires HTTPS (localhost is allowed for development).

## Current prototype limits / next engineering steps
1. Add server-side test node provisioning in Jakarta and Singapore.
2. Add adaptive test sizes and longer multi-stage runs for high-speed connections.
3. Add loaded-latency measurements while download/upload are running.
4. Add server-side ICMP probes for packet-loss diagnostics, clearly distinguish server-to-target loss from client access loss.
5. Add persistent history/account sync only if needed; current history is stored locally in the browser.
6. Add rate limiting, abuse protection, bandwidth safeguards, and monitoring before public launch.
