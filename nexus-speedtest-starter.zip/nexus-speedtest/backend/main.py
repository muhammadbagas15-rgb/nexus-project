import os, time, math, asyncio, statistics
from typing import Optional
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel

app = FastAPI(title="NEXUS SPEEDTEST API", version="1.0.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware, allow_origins=origins, allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"]
)

SERVER_ID = os.getenv("NEXUS_SERVER_ID", "local")
SERVER_NAME = os.getenv("NEXUS_SERVER_NAME", "NEXUS Local Test Server")
SERVER_LOCATION = os.getenv("NEXUS_SERVER_LOCATION", "Configure location")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(64 * 1024 * 1024)))

class PingRequest(BaseModel):
    samples: int = 10

@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "nexus-speedtest", "server_id": SERVER_ID}

@app.get("/api/servers")
async def servers():
    # Additional real test servers can be registered with NEXUS_SERVERS_JSON.
    # Each entry must point to a deployed NEXUS backend, not a decorative listing.
    raw = os.getenv("NEXUS_SERVERS_JSON", "")
    extra = []
    if raw:
        try:
            extra = __import__("json").loads(raw)
        except Exception:
            extra = []
    local = {
        "id": SERVER_ID, "name": SERVER_NAME, "location": SERVER_LOCATION,
        "baseUrl": "", "enabled": True, "isLocal": True
    }
    return {"servers": [local] + [s for s in extra if s.get("baseUrl") and s.get("id")]}

def byte_stream(total_bytes: int, chunk_size: int = 256 * 1024):
    chunk = b"0" * chunk_size
    sent = 0
    while sent < total_bytes:
        n = min(chunk_size, total_bytes - sent)
        yield chunk[:n]
        sent += n

@app.get("/api/download")
async def download(size: int = 25_000_000):
    size = max(1_000_000, min(int(size), 100_000_000))
    headers = {
        "Content-Length": str(size),
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "X-Content-Type-Options": "nosniff"
    }
    return StreamingResponse(byte_stream(size), media_type="application/octet-stream", headers=headers)

@app.post("/api/upload")
async def upload(request: Request):
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Upload test exceeds configured limit")
    received = 0
    async for chunk in request.stream():
        received += len(chunk)
        if received > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail="Upload test exceeds configured limit")
    return JSONResponse({"received_bytes": received, "status": "ok"},
                        headers={"Cache-Control": "no-store"})

@app.get("/")
async def root():
    return {"name": "NEXUS SPEEDTEST", "api": "/api/health"}
